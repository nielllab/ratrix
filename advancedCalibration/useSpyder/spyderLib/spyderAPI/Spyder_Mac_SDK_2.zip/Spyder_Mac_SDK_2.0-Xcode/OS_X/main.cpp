
// Copyright 2006 ColorVision Inc

#include <time.h>
#include <stdio.h>

#include "cvimport.h"

enum
{
	kCRT = 1,
	kLCD = 2
};

#define lcall(a) CV##a


int 
main()
{
	int		k;
	int		CRTLCD;
	
	UINT32	err;
	UINT8	rVal;
	FLOAT32 rate;
	UINT16	frames;
	UINT8	sysErr;
	FLOAT32	X, Y, Z;
	clock_t	start, stop;
	CV_VendorData_S vd;
	SINT32  _rate, _xx, _yy, _zz;
	
	char str[32];


	start = clock();
	printf( "\nCV_Startup\n" );

	rVal = lcall(_Startup)( &vd );
	if( rVal != CV_STATUS_SUCCESS ) 
	{
		printf( "CV_Startup failed\n" );
		err = lcall(_GetDetailedError)( &sysErr );
		printf( "err 0x%08X, sysErr %d\n", err, sysErr );
		return -2;
	};

	stop = clock();
	printf( "CV_Startup complete %4.2f seconds\n", (stop-start)*1.0/CLOCKS_PER_SEC );
	printf( "Spyder SN " ); for( int i=0; i<8; i++ ) printf( "%c", vd.SerialNumber[i] ); printf( "\n" );

	printf( "\nAttach sensor to screen and then press c<return> to continue\n" );
	fflush( stdout );
	scanf( "%s", str );

	printf( "\nCV_GetRefreshRate\n" );
	rVal = lcall(_GetRefreshRate)( &_rate );
	if( rVal != CV_STATUS_SUCCESS ) 
	{
		printf( "CV_GetRefreshRate failed\n" );
		err = lcall(_GetDetailedError)( &sysErr );
		printf( "err 0x%08X, sysErr %d\n", err, sysErr );

		if( err == CV_WARNING_APPARENTLY_NOT_CRT || err == CV_WARNING_TRIGGER_TIMEOUT )
		{
			err = 0;
		}
		if( err ) _rate = 75 * 1000;
	};

	rate = _rate / 1000.;
	printf( "Refresh rate %f\n", rate );

	k=1;
	frames = (UINT16)(2*rate); //frame count for two second readings

	while (k) 
	{
		str[0] = 'c';
		printf( "\nEnter c<return> for CRT, l<return> for LCD? " );
		fflush(stdout);
		scanf( "%s", str );
		if( str[0] == 'c') CRTLCD = kCRT; else CRTLCD = kLCD;
		printf( "\n" );

		err = 0;
		printf( "\nCV_UseCalibration\n" );
		rVal = lcall(_UseCalibration)( CRTLCD );
		if( rVal != CV_STATUS_SUCCESS  )
		{
			err = lcall(_GetDetailedError)( &sysErr );
			printf( "CV_UseCalibration(%d) failed - err =  %d (0x%08X), sysErr = %d\n\n", CRTLCD, err, err, sysErr );
		}
	
		err = 0;
		printf( "\nCV_GetXYZ\n" );
		rVal = lcall(_GetXYZ)( frames, &_xx, &_yy, &_zz );

		if( rVal != CV_STATUS_SUCCESS ) 
		{
			printf( "CV_GetXYZ failed\n" );
			err = lcall(_GetDetailedError)( &sysErr );
			printf( "err 0x%08X, sysErr %d\n", err, sysErr );

			if( err == CV_WARNING_APPARENTLY_NOT_CRT || err == CV_WARNING_TRIGGER_TIMEOUT )
			{
				err = 0;
			}
		};

		X = _xx / 1000.; Y = _yy / 1000.; Z = _zz / 1000.; 
		if( err == 0 ) printf( "xy : %6.3f %6.3f\n", X/(X+Y+Z), Y/(X+Y+Z) );
		if( err == 0 ) printf( "XYZ: %6.2f %6.2f %6.2f\n", X, Y, Z );

		str[0] = 'q';
		printf( "\nEnter q<return> to quit, c<return> to read again? " );
		fflush(stdout);
		scanf( "%s", str );
		k = (str[0] != 'q');
		printf( "\n" );
	}

	printf( "\nCV_Shutdown\n" );
	lcall(_Shutdown)();

	return 0;
}

